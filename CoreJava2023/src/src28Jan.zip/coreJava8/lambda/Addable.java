package coreJava8.lambda;
@FunctionalInterface
interface Addable{  
    int add(int a,int b);  
} 