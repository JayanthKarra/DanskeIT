package scanner;

public class Scanner {
	public static void main(String args[]){  
        java.util.Scanner in = new java.util.Scanner(System.in);  
        System.out.print("Enter your name: ");  
        String name = in.next();  
        System.out.println("Name is: " + name);             
        in.close();             
        }  
} 

